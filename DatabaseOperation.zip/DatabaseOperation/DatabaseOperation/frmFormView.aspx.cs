﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DatabaseOperation
{
    public partial class frmFormView : System.Web.UI.Page
    {
        String connect = "server=(localdb)\\MSSQLLocaLDB;database=CollegeDB;Trusted_Connection=true;";
        protected void Page_Load(object sender, EventArgs e)
        {
           
        
            if (!IsPostBack)
            {
                DataTable dt = GetCourse();
                frmviewCourse.DataSource = dt;
                frmviewCourse.DataBind();

            }
        }

        private DataTable GetCourse()
        {
            SqlConnection sqlcon = new SqlConnection();
            sqlcon.ConnectionString = connect;
            SqlCommand sqlcom = new SqlCommand("Select * from Course", sqlcon);
            SqlDataAdapter sqlData = new SqlDataAdapter(sqlcom);
            DataTable dt = new DataTable();
            sqlData.Fill(dt);
          foreach (DataRow dr in dt.Rows)
            {
                if (String.IsNullOrEmpty(dr["Logo"].ToString()))
                {
                    dr["Logo"] = "~/Image/boy.png";
                }
                else
                {
                    dr["Logo"] = "~/Image/" + dr["Logo"];
                }
            }
          return dt;
        }

        protected void frmviewCourse_PageIndexChanging(object sender, FormViewPageEventArgs e)
        {
            frmviewCourse.PageIndex=e.NewPageIndex;
            DataTable dt=GetCourse();
            frmviewCourse.DataSource = dt;
            frmviewCourse.DataBind();
        }

        protected void frmviewCourse_ModeChanging(object sender, FormViewModeEventArgs e)
        {

        }

        protected void frmviewCourse_ItemUpdating(object sender, FormViewUpdateEventArgs e)
        {
            if (Page.IsValid)
            {
                String name = e.NewValues["Name"].ToString();
                String desc = e.NewValues["Description"].ToString();   
                FileUpload fileUpload =frmviewCourse.FindControl("fuLogo") as FileUpload;
                String fileName = string.Empty;
                if (fileUpload.HasFile)
                {
                    fileName=DateTime.Now.ToString("ddMMyyyymmss")+fileUpload.FileName;
                    String filepath=System.IO.Path.Combine(MapPath("~/Image/"),fileName);
                    fileUpload.SaveAs(filepath);
                }
                String updateQuery = string.Empty;
                SqlConnection sqlcon = new SqlConnection();
                sqlcon.ConnectionString = connect;
                SqlCommand sqlCommand = new SqlCommand();
                if (fileName != string.Empty)
                {
                    updateQuery = "Update Course set Name=@Name,Description=@Description,Logo=@Logo where CourseId=@CourseId";
                    sqlCommand.Parameters.Add("@Logo",SqlDbType.VarChar,50).Value=fileName;
                }
                else
                {
                    updateQuery = "Update Course set Name=@Name,Description=@Description where CourseId=@CourseId";
                }
                sqlCommand.CommandText=updateQuery;
                sqlCommand.Connection=sqlcon;
                sqlCommand.Parameters.Add("@Name",SqlDbType.VarChar,20).Value=name;
                sqlCommand.Parameters.Add("@Description", SqlDbType.VarChar, 100).Value = desc;
                sqlCommand.Parameters.Add("@CourseId", SqlDbType.Int).Value = frmviewCourse.DataKey.Value;
                sqlcon.Open();
                sqlCommand.ExecuteNonQuery();
                sqlcon.Close();
                sqlcon.Dispose();
                frmviewCourse.ChangeMode(FormViewMode.ReadOnly);
                frmviewCourse.AllowPaging = true;
                DataTable dt = GetCourse();
                frmviewCourse.DataSource = dt;
                frmviewCourse.DataBind();
            }
        }

        protected void frmviewCourse_ItemDeleting(object sender, FormViewDeleteEventArgs e)
        {
            SqlConnection sqlConn = new SqlConnection();
            sqlConn.ConnectionString = connect;
            String deleteQuery = "Delete from Course where CourseId=@CourseId";
            SqlCommand sqlCommand=new SqlCommand(deleteQuery,sqlConn);
            sqlCommand.Parameters.Add("@CourseId", SqlDbType.Int).Value = Convert.ToInt32(frmviewCourse.DataKey.Value);
            sqlConn.Open();
            sqlCommand.ExecuteNonQuery();
            sqlConn.Close();
            sqlConn.Dispose();
            frmviewCourse.ChangeMode(FormViewMode.ReadOnly);
            frmviewCourse.AllowPaging = true;
            DataTable dt = GetCourse();
            frmviewCourse.DataSource = dt;
            frmviewCourse.DataBind();
        }

        protected void frmviewCourse_ItemCommand(object sender, FormViewCommandEventArgs e)
        {
            DataTable dt = new DataTable();
            if (e.CommandName == "Delete")
            {
                frmviewCourse.ChangeMode(FormViewMode.ReadOnly);
                frmviewCourse.AllowPaging=true;
                dt=GetCourse();
                frmviewCourse.DataSource=dt;
                frmviewCourse.DataBind();
            }
            else if(e.CommandName == "Edit")
            {
                frmviewCourse.ChangeMode(FormViewMode.Edit); 
                frmviewCourse.AllowPaging=true; 
                dt=GetCourse();
                frmviewCourse.DataSource=dt;    
                frmviewCourse.DataBind();
            }
            else if(e.CommandName == "New")
            {
                frmviewCourse.ChangeMode(FormViewMode.Insert);
                frmviewCourse.AllowPaging=true;
                dt=GetCourse();
                frmviewCourse.DataSource=dt;
                frmviewCourse.DataBind();
            }
            else if(e.CommandName == "Cancel")
            {
                frmviewCourse.ChangeMode(FormViewMode.ReadOnly);
                frmviewCourse.AllowPaging=true;
                dt=GetCourse();
                frmviewCourse.DataSource = dt;
                frmviewCourse.DataBind();
            }
        }

        protected void frmviewCourse_ItemInserting(object sender, FormViewInsertEventArgs e)
        {
            if(Page.IsValid)
            {
                String name = e.Values["Name"].ToString();
                String desc = e.Values["Description"].ToString();
                FileUpload fileUpload=frmviewCourse.FindControl("fuLogo") as FileUpload;
                String fileName=string.Empty;
                if (fileUpload.HasFile)
                {
                    fileName = DateTime.Now.ToString("ddMMyyyymmss") + fileUpload.FileName;
                    String filepath=System.IO.Path.Combine(MapPath("~/Image/"),fileName);
                    fileUpload.SaveAs(filepath);
                }
                String insertQuery = string.Empty;
                SqlConnection sqlcon = new SqlConnection();
                sqlcon.ConnectionString = connect;
                SqlCommand sqlCommand = new SqlCommand();
                if (fileName != string.Empty)
                {
                    insertQuery = "Insert into Course (Name,Description,Logo)values(@Name,@Description,@Logo)";
                    sqlCommand.Parameters.Add("@Logo",SqlDbType.VarChar,50).Value = fileName;
                }
                else
                {
                    insertQuery = "Insert into Course (Name,Description)values(@Name,@Description)";
                }
                sqlCommand.CommandText = insertQuery;
                sqlCommand.Connection = sqlcon;
                sqlCommand.Parameters.Add("@Name",SqlDbType.VarChar,20).Value = name;
                sqlCommand.Parameters.Add("@Description",SqlDbType.VarChar,100).Value = desc;
                sqlcon.Open();
                sqlCommand.ExecuteNonQuery();
                sqlcon.Close();
                sqlcon.Dispose();
                frmviewCourse.ChangeMode(FormViewMode.ReadOnly);
                frmviewCourse.AllowPaging = true;
                DataTable dt = GetCourse();
                frmviewCourse.DataSource = dt;
                frmviewCourse.DataBind();
            }
        }
    }
}
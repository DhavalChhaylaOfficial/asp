﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment1
{
    public partial class frmCalculator : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtNo1.Text == string.Empty)
            {
                lblErr1.Text = "Enter No1 Please";
                lblErr2.Text = "*";
            }

            else if (txtNo2.Text == string.Empty)
            {
                lblErr1.Text = "*";
                lblErr2.Text = "Enter No2 Please";
            }

            else
            {
                lblErr1.Text = "*";
                lblErr2.Text = "*";
                int no1, no2, result;
                no1 = Convert.ToInt32(txtNo1.Text);
                no2 = Convert.ToInt32(txtNo2.Text);
                result = no1 + no2;
                lblResult.Text = Convert.ToString(result);
            }
        }

        protected void btnSub_Click(object sender, EventArgs e)
        {
            int no1, no2, result;
           
            if (txtNo1.Text == string.Empty)
            {
                lblErr1.Text = "Enter No1 Please";
                lblErr2.Text = "*";
                return;
            }

            if (txtNo2.Text == string.Empty)
            {
                lblErr2.Text = "Enter No2 Please";
                lblErr1.Text = "*";
                return;
            }

            no1 = Convert.ToInt32(txtNo1.Text);
            no2 = Convert.ToInt32(txtNo2.Text);

            if (no1 >= no2)
            {
                lblErr1.Text = "*";
                lblErr2.Text = "*";
                result = no1 - no2;
                lblResult.Text = Convert.ToString(result);
            }

            else
            {
                lblResult.Text = "Make sure No1 is bigger than No2";
            }
        }

        protected void btnMul_Click(object sender, EventArgs e)
        {
            if (txtNo1.Text == string.Empty)
            {
                lblErr1.Text = "Enter No1 Please";
                lblErr2.Text = "*";
            }

            else if (txtNo2.Text == string.Empty)
            {
                lblErr1.Text = "*";
                lblErr2.Text = "Enter No2 Please";
            }

            else
            {
                lblErr1.Text = "*";
                lblErr2.Text = "*";
                double no1, no2, result;
                no1 = Convert.ToDouble(txtNo1.Text);
                no2 = Convert.ToDouble(txtNo2.Text);
                result = no1 * no2;
                lblResult.Text = Convert.ToString(result);
            }
        }

        protected void btnDiv_Click(object sender, EventArgs e)
        {
            double no1, no2, result;
           
            if (txtNo1.Text == string.Empty)
            {
                lblErr1.Text = "Enter No1 Please";
                lblErr2.Text = "*";
                return;
            }

            if (txtNo2.Text == string.Empty)
            {
                lblErr2.Text = "Enter No2 Please";
                lblErr1.Text = "*";
                return;
            }

            no1 = Convert.ToDouble(txtNo1.Text);
            no2 = Convert.ToDouble(txtNo2.Text);

            if (no1!=0 && no2!=0)
            {
                lblErr1.Text = "*";
                lblErr2.Text = "*";
                result = no1 / no2;
                lblResult.Text = Convert.ToString(result);
            }

            else
            {
                lblResult.Text = "given number cannot divided by 0";
            }
        }

        protected void btnPow_Click(object sender, EventArgs e)
        {
            if (txtNo1.Text == string.Empty)
            {
                lblErr1.Text = "Enter No1 Please";
                lblErr2.Text = "*";
                return;
            }

            else if (txtNo2.Text == string.Empty)
            {
                lblErr2.Text = "Enter No2 Please";
                lblErr1.Text = "*";
                return;
            }

            else
            {
                lblErr1.Text = "*";
                lblErr2.Text = "*";

                int baseNumber, expNumber;
                double result = 1;

                baseNumber = Convert.ToInt32(txtNo1.Text);
                expNumber = Convert.ToInt32(txtNo2.Text);

                bool sing = false;
                if (expNumber > 0) sing = true;
                expNumber = Math.Abs(expNumber);

                for (int i = 1; i <= expNumber; i++)
                {
                    if (sing)
                        result = result * baseNumber;
                    else
                        result /= baseNumber;
                }
                lblResult.Text = Convert.ToString(result);
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment1
{
    public partial class frmLoops : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            body1.Attributes["bgcolor"] = "Black";
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            int num = Convert.ToInt32(txtNo.Text);
            string result = "";
            for (int i = 1; i <= num; i++)
            {
                result += i.ToString() + ",";  
            }
            lblResult.Text = result.TrimEnd(',');
        }

        protected void btnSumit1_Click(object sender, EventArgs e)
        {
            int num1 = Convert.ToInt32(txtNo1.Text);
            int num2 = Convert.ToInt32(txtNo2.Text);
            string result = "";

            for(int i = num1; i <= num2; i++)
            {
                result += i.ToString() +",";
            }
            lblResult1.Text = result.TrimEnd(',');
        }

        protected void btnSubmit2_Click(object sender, EventArgs e)
        {
            int num1 = Convert.ToInt32(txtNum1.Text);
            int num2 = Convert.ToInt32(txtNum2.Text);
            int step = Convert.ToInt32(txtStep.Text);
            string result = "";

            for(int i = num1; i <= num2; i+=step)
            {
                result += i.ToString() + ",";
            }
            lblresult2.Text = result.TrimEnd(',');
        }
    }
}
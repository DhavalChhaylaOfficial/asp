﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment1
{
    public partial class Que7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblResult.Text = string.Empty;
            if (IsPostBack == false)
            {
                ListItem itemIndia = new ListItem();
                itemIndia.Text = "India";
                itemIndia.Value = "India";

                ddlOprdynamic.Items.Add(itemIndia);
                ListItem itemAfghanistan = new ListItem();
                itemAfghanistan.Text = "Afghanistan";
                itemAfghanistan.Value = "Afghanistan";

                ddlOprdynamic.Items.Add(itemAfghanistan);
                ListItem itemAustralia = new ListItem();
                itemAustralia.Text = "Australia";
                itemAustralia.Value = "Australia";

                ddlOprdynamic.Items.Add(itemAustralia);
                ListItem itemCanada = new ListItem();
                itemCanada.Text = "Canada";
                itemCanada.Value = "Canada";

                ddlOprdynamic.Items.Add(itemCanada);
                ListItem itemChina = new ListItem();
                itemChina.Text = "China";
                itemChina.Value = "China";

                ddlOprdynamic.Items.Add(itemChina);
                ListItem itemFrance = new ListItem();
                itemFrance.Text = "France";
                itemFrance.Value = "France";

                ddlOprdynamic.Items.Add(itemFrance);
                ListItem itemJapan = new ListItem();
                itemJapan.Text = "Japan";
                itemJapan.Value = "Japan";

                ddlOprdynamic.Items.Add(itemJapan);
                ListItem itemBrazil = new ListItem();
                itemBrazil.Text = "Brazil";
                itemBrazil.Value = "Brazil";

                ddlOprdynamic.Items.Add(itemBrazil);
                ListItem itemBhutan = new ListItem();
                itemBhutan.Text = "Bhutan";
                itemBhutan.Value = "Bhutan";

                ddlOprdynamic.Items.Add(itemBhutan);
                ListItem itemBangladesh = new ListItem();
                itemBangladesh.Text = "Bangladesh";
                itemBangladesh.Value = "Bangladesh";
                ddlOprdynamic.Items.Add(itemBangladesh);
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            bool error = false;
            if (txtFirstName.Text.Length > 20)
            {
                lblValidationMessage1.Text = "First Name should not exceed 20 characters.";
                error = true;
            }
            if (txtLastName.Text.Length > 20)
            {
                lblValidationMessage2.Text = "Last Name should not exceed 20 characters.";
                error = true;
            }

            if (txtZipCode.Text.Length != 6)
            {
                lblValidationMessage3.Text = "Zipcode should be a 6-digit number.";
                error = true;
            }
            if (ddlOprdynamic.SelectedIndex == 0)
            {
                lblValidationMessage4.Text = "Please select a valid country.";
                error = true;
            }
            if (error == false)
            {
                lblResult.Text = "<br>First Name : " + txtFirstName.Text;
                lblResult.Text += "<br>Last Name : " + txtLastName.Text;
                lblResult.Text += "<br>Birthdate : " + txtBirthDate.Text;
                lblResult.Text += "<br>Address : " + txtFirstName.Text;
                lblResult.Text += "<br>Zipcode : " + txtZipCode.Text;
                lblResult.Text += "<br>Country : " + ddlOprdynamic.SelectedValue;
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtBirthDate.Text = "";
            txtAddress.Text = "";
            txtZipCode.Text = "";
            ddlOprdynamic.SelectedIndex = 0;
            lblValidationMessage1.Text = "";
            lblValidationMessage2.Text = "";
            lblValidationMessage3.Text = "";
            lblValidationMessage4.Text = "";
            lblResult.Text = "";
        }
    }
}
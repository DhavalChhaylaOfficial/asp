﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment1
{
    public partial class frmAgeVal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtName.Text == string.Empty)
            {
                lblErr1.Text = "Enter Name Please";
                lblErr2.Text = "*";
                return;
            }

            if (txtAge.Text == string.Empty)
            {
                lblErr1.Text = "*";
                lblErr2.Text = "Enter Age Please";
                return;
            }

            if(Convert.ToInt32(txtAge.Text) > 18)
            {
                lblErr1.Text = "*";
                lblErr2.Text = "*";

                lblresult.Text = "Name: " + txtName.Text + "<br>Age: " + txtAge.Text;
            }

            else
            {
                lblErr1.Text = "*";
                lblErr2.Text = "*";

                lblresult.Text = "Age must be above 18";
            }
        }
    }
}
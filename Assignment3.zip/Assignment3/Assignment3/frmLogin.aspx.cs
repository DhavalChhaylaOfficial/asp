﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment3
{
    public partial class frmLogin : System.Web.UI.Page
    {
        String connectionString = "Data Source=(localdb)\\ProjectModels;Initial Catalog=SalesDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            lblnameerror.Text = "*";
            passerror.Text = "*";
            int error = 0;
            if (txtName.Text == String.Empty)
            {
                lblnameerror.Text = "Name is required";
                error = 1;
            }
            if (txtpass.Text == String.Empty)
            {
                passerror.Text = "Password is required";
                error = 1;
            }
            if (error == 0)
            {
                string username = txtName.Text.Trim();
                string password = txtpass.Text.Trim();

                SqlConnection sqlConn = new SqlConnection();
                sqlConn.ConnectionString = connectionString;
                string query = "SELECT COUNT(*) FROM Register WHERE UserName = @Username AND Password = @Password";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConn);
                sqlCommand.Parameters.AddWithValue("@Username", username);
                sqlCommand.Parameters.AddWithValue("@Password", password);
                sqlConn.Open();
                int count = (int)sqlCommand.ExecuteScalar();
                if (count == 1)
                {
                    errormsg.Text = "done";
                    Response.Redirect("frmSaleslist.aspx");
                }
                else
                {
                    errormsg.Text = "Invalid username or password.";
                }
                sqlConn.Close();
            }
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtName.Text = string.Empty;
            txtpass.Text = string.Empty;
            Response.Redirect("frmRegister.aspx");
        }
        protected void btnreset_Click(object sender, EventArgs e)
        {
            txtName.Text = string.Empty;
            txtpass.Text = string.Empty;
        }

    }
}
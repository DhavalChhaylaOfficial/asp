﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment3
{
    public partial class frmProductlist : System.Web.UI.Page
    {
        private String connectionString = "server=(localdb)\\ProjectModels;database=SalesDB;Trusted_Connection=true;";
        int catid;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["CatId"] != null)
            {
                catid = Convert.ToInt32(Request.QueryString["CatId"]);
            }
            else
            {
                catid = 1;
            }
            BindData();
        }
        private void BindData()
        {
            DataTable dt = Getproduct();
            dlProduct.DataSource = dt;
            dlProduct.DataBind();
        }
        private DataTable Getproduct()
        {
            SqlConnection sqlconn = new SqlConnection(connectionString);
            String query = "Select ProductId,P.Name as Product, Qty,Rate, P.Logo, C.CatId, C.Name as" + " Category from Product as P inner Join Category as C " + "on P.CatId = C.CatId where P.CatId= " + catid;
            SqlCommand sqlCommand = new SqlCommand(query, sqlconn);
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            DataTable dt = new DataTable();
            sqlDataAdapter.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                if (String.IsNullOrEmpty(dr["Logo"].ToString()))
                {
                    dr["Logo"] = "~/Images/Product.png";
                }
                else
                {
                    dr["Logo"] = "~/Images/" + dr["Logo"]; ;
                }
            }
            return dt;
        }
        protected void dlProduct_EditCommand(object source, DataListCommandEventArgs e)
        {
            HiddenField hidden = dlProduct.Items[e.Item.ItemIndex].
            FindControl("hdCatId") as HiddenField;
            String courseId = hidden.Value;
            dlProduct.EditItemIndex = e.Item.ItemIndex;
            DropDownList ddlCourse = dlProduct.Items[e.Item.ItemIndex].
            FindControl("ddlCourse") as DropDownList;
            DataTable dt = GetCategory();
            ddlCourse.DataSource = dt;
            ddlCourse.DataTextField = "Name";
            ddlCourse.DataValueField = "CourseId";
            ddlCourse.DataBind();
            ddlCourse.SelectedValue = courseId;
        }
        private DataTable GetCategory()
        {
            SqlConnection sqlconn = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand("Select CatId, Name from Category ",
           sqlconn);
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            DataTable dt = new DataTable();
            sqlDataAdapter.Fill(dt);
            return dt;
        }
        protected void dlProduct_DeleteCommand(object source, DataListCommandEventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            int index = e.Item.ItemIndex;
            String deletequery = "Delete from Product where ProductId = @ProductId";
            SqlCommand sqlCommand = new SqlCommand(deletequery, sqlConnection);
            sqlCommand.Parameters.Add("@ProductId", SqlDbType.Int).Value =
            Convert.ToInt32(dlProduct.DataKeys[index]);
            sqlConnection.Open();
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            sqlConnection.Dispose();
            BindData();
            Response.Write("<script>alert('Record deleted successfully');</script>");
        }
        protected void dlProduct_CancelCommand(object source, DataListCommandEventArgs e)
        {
            dlProduct.EditItemIndex = -1; 
            BindData();
        }
        protected void dlProduct_UpdateCommand(object source, DataListCommandEventArgs e)
        {
            int currentIndex = e.Item.ItemIndex;
            String name = ((TextBox)dlProduct.Items[currentIndex].FindControl("txtName")).Text;
            String CatId = ((DropDownList)dlProduct.Items[e.Item.ItemIndex].FindControl("ddlCategory")).SelectedValue;
            int ProductId = Convert.ToInt32(dlProduct.DataKeys[currentIndex]);
            String Qty = ((TextBox)dlProduct.Items[currentIndex].FindControl("txtQty")).Text;
            String Rate = ((TextBox)dlProduct.Items[currentIndex].FindControl("txtRate")).Text;
            FileUpload fileUpload = dlProduct.Items[currentIndex].FindControl("fuLogo") as FileUpload;
            String fileName = string.Empty;

            if (fileUpload.HasFile)
            {
                fileName = DateTime.Now.ToString("ddMMyyyymmss") + fileUpload.FileName;
                string filePath = System.IO.Path.Combine(MapPath("~/Images/"), fileName);
                fileUpload.SaveAs(filePath);
            }
            string updateQuery = string.Empty;
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand();
            if (fileName != string.Empty)
            {
                updateQuery = "update Product set Name= @Name , Qty= @Qty, Rate=@Rate,  Logo = @Logo," + " CatId=@CatId where ProductId= @ProductId";
                sqlCommand.Parameters.Add("@Logo", SqlDbType.VarChar, 50).Value = fileName;
            }
            else
            {
                updateQuery = "update Product set Name= @Name , Qty= @Qty, Rate=@Rate" +
                " CatId=@CatId where ProductId= @ProductId";
            }
            sqlCommand.CommandText = updateQuery;
            sqlCommand.Connection = sqlConnection;
            sqlCommand.Parameters.Add("@Name", SqlDbType.VarChar, 20).Value = name;
            sqlCommand.Parameters.Add("@Qty", SqlDbType.Int).Value = Qty;
            sqlCommand.Parameters.Add("@Rate", SqlDbType.Int).Value = Qty;
            sqlCommand.Parameters.Add("@CatId", SqlDbType.Int).Value = catid;
            sqlCommand.Parameters.Add("@ProductId", SqlDbType.Int).Value = ProductId;
            sqlConnection.Open();
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            sqlConnection.Dispose();
            dlProduct.EditItemIndex = -1;
            BindData();
            Response.Write("<script>alert('Data edit Successfully')</script>");
        }
    }
}



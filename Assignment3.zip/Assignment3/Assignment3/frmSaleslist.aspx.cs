﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment3
{
    public partial class frmSaleslist : System.Web.UI.Page
    {
        private String connectionString =
            "Data Source=(localdb)\\ProjectModels;Initial Catalog=SalesDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False;";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindSalesData();
            }
        }
        protected void BindSalesData()
        {
            SqlConnection sqlconn = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand("SELECT CatId, Name FROM Category ", sqlconn);
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            DataTable dt = new DataTable();
            sqlDataAdapter.Fill(dt);
            dlsales.DataSource = dt;
            dlsales.DataBind();
        }
        protected void dlsales_EditCommand(object source, DataListCommandEventArgs e)
        {
            dlsales.EditItemIndex = e.Item.ItemIndex;
            BindSalesData();
        }
        protected void dlsales_DeleteCommand(object source, DataListCommandEventArgs e)
        {
        }
        protected void dlsales_CancelCommand(object source, DataListCommandEventArgs e)
        {
            dlsales.EditItemIndex = -1;
            BindSalesData();
        }
        protected void dlsales_UpdateCommand(object source, DataListCommandEventArgs e)
        {
            TextBox txtEditId = e.Item.FindControl("txtEditId") as TextBox;
            TextBox txtEditName = e.Item.FindControl("txtEditName") as TextBox;
            if (txtEditId != null && txtEditName != null)
            {
                int categoryId = Convert.ToInt32(txtEditId.Text);
                string updatedName = txtEditName.Text;

                SqlConnection sqlConn = new SqlConnection();
                sqlConn.ConnectionString = connectionString;
                String updateQuery = "Update Category set Name=@Name where CatId = @CatId";
                SqlCommand sqlCommand = new SqlCommand(updateQuery, sqlConn);
                sqlCommand.Parameters.Add("@Name", SqlDbType.VarChar).Value = updatedName;
                sqlCommand.Parameters.Add("@CatId", SqlDbType.Int).Value = categoryId;
                sqlConn.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConn.Close();
                sqlConn.Dispose();

                dlsales.EditItemIndex = -1;
                BindSalesData();
            }
        }
        protected void dlsales_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                int CatId = Convert.ToInt32(e.CommandArgument);
                SqlConnection sqlConnection = new SqlConnection(connectionString);
                String deletequery = "Delete from Category where CatId = @CatId";
                SqlCommand sqlCommand = new SqlCommand(deletequery, sqlConnection);
                sqlCommand.Parameters.Add("@CatId", SqlDbType.Int).Value = CatId;
                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();
                sqlConnection.Dispose();
                DataTable dt = new DataTable();

                Response.Write("<script>alert('Record deleted successfully')</script>");
                BindSalesData();
            }
        }
    }
}
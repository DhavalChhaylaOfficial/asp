﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace Assignment3
{
    public partial class frmRegister : System.Web.UI.Page
    {
        String connectionString = "Data Source=(localdb)\\ProjectModels;Initial Catalog=SalesDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnRegister_Click(object sender, EventArgs e)
        {
            lblnameerror.Text = "*";
            lblemailerror.Text = "*";
            lblgenerror.Text = "*";
            passerror.Text = "*";
            int error = 0;
            String Gender = "";
            if (txtName.Text == String.Empty)
            {
                lblnameerror.Text = "Name is reuired";
                error = 1;
            }
            if (txtEmail.Text == String.Empty)
            {
                lblemailerror.Text = "Email is required";
                error = 1;
            }
            if (txtpass.Text == String.Empty)
            {
                lblpass.Text = "password is required";
                error = 1;
            }
            if (rbtnmale.Checked)
            {
                Gender = rbtnmale.Text;
            }
            else if (rbtnFemale.Checked)
            {
                Gender = rbtnFemale.Text;
            }
            else
            {
                lblgenerror.Text = "Gender is required";
                error = 1;
            }
            if (error == 0)
            {

                SqlConnection sqlConn = new SqlConnection();
                sqlConn.ConnectionString = connectionString;
                String insertquery = "Insert into Register values(@Name, @Email, @pass, @gender)";
                SqlCommand sqlCommand = new SqlCommand(insertquery, sqlConn);
                sqlCommand.Parameters.Add("@Name", SqlDbType.VarChar, 20).Value =
               txtName.Text;
                sqlCommand.Parameters.Add("@Email", SqlDbType.VarChar, 100).Value =
               txtEmail.Text;
                sqlCommand.Parameters.Add("@pass", SqlDbType.VarChar, 100).Value =
               txtpass.Text;
                sqlCommand.Parameters.Add("@gender", SqlDbType.VarChar, 100).Value = Gender;
                sqlConn.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConn.Close();
                sqlConn.Dispose();
                Response.Redirect("frmLogin.aspx");
            }

        }
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("frmLogin.aspx");
        }

        protected void btnreset_Click(object sender, EventArgs e)
        {
            txtName.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtpass.Text = string.Empty;

        }

        protected void btnLogin_Click1(object sender, EventArgs e)
        {

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace Assignment3
{
    public partial class frmAddProduct : System.Web.UI.Page
    {
        private String connectionString = "server=(localdb)\\ProjectModels;database=SalesDB;Trusted_Connection=true;";

        protected void Page_Load(object sender, EventArgs e)
        {
            DropDownList ddlCategory = fvaddProduct.FindControl("ddlCategory") as DropDownList;

            ListItem item = new ListItem();
            item.Text = "All";
            item.Value = "0";
            ddlCategory.DataSource = GetCagory();
            ddlCategory.DataTextField = "Name";
            ddlCategory.DataValueField = "CatId";
            ddlCategory.DataBind();
            ddlCategory.Items.Insert(0, item);
        }
        private DataTable GetCagory()
        {
            SqlConnection sqlconn = new SqlConnection(connectionString);
            SqlCommand sqlCommand = new SqlCommand("Select CatId, Name from Category ", sqlconn);
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            DataTable dt = new DataTable();
            sqlDataAdapter.Fill(dt);
            return dt;
        }
        protected void fvaddProduct_ItemInserting(object sender, FormViewInsertEventArgs e)
        {
            if (Page.IsValid)
            {
                String name = e.Values["Product"].ToString();
                int qty = Convert.ToInt32(e.Values["Qty"]);
                int Rate = Convert.ToInt32(e.Values["Rate"]);
                String cat =
               ((DropDownList)fvaddProduct.FindControl("ddlCategory")).SelectedValue;
                int catid = Convert.ToInt32(cat);
                FileUpload fileUpload = fvaddProduct.FindControl("fuLogo") as FileUpload;
                String fileName = string.Empty;
                if (fileUpload.HasFile)
                {
                    fileName = DateTime.Now.ToString("ddMMyyyymmss") + fileUpload.FileName;
                    String filePath = System.IO.Path.Combine(MapPath("~/Images/"),
                    fileName);
                    fileUpload.SaveAs(filePath);
                }
                String insertQuery = string.Empty;
                SqlConnection sqlConn = new SqlConnection();
                sqlConn.ConnectionString = connectionString;
                SqlCommand sqlCommand = new SqlCommand();
                if (fileName != string.Empty)
                {
                    insertQuery = "insert into Product (Name,Qty,Rate,Logo,CatId) values(@Name, @Qty, @Rate, @Logo, @Catid)";
                    sqlCommand.Parameters.Add("@Logo", SqlDbType.VarChar, 50).Value = fileName;
                }
                else
                {
                    insertQuery = "insert into Product (Name,Qty,Rate,CatId) values(@Name, @Qty, @Rate, @Catid)";
                }
                sqlCommand.CommandText = insertQuery;
                sqlCommand.Connection = sqlConn;
                sqlCommand.Parameters.Add("@Name", SqlDbType.VarChar, 20).Value = name;
                sqlCommand.Parameters.Add("@Qty", SqlDbType.Int).Value = qty;
                sqlCommand.Parameters.Add("@Rate", SqlDbType.Int).Value = Rate;
                sqlCommand.Parameters.Add("@CatId", SqlDbType.Int).Value = catid;
                sqlConn.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConn.Close();
                sqlConn.Dispose();
                Response.Redirect("frmProductList.aspx");
            }
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("frmProductList.aspx");
        }
    }
}
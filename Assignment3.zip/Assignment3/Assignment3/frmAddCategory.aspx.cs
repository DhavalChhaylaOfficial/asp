﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment3
{
    public partial class frmAddCategory : System.Web.UI.Page
    {
        private String connectionString = "server=(localdb)\\ProjectModels;database=SalesDB;Trusted_Connection=true;";
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void fvaddcat_ItemInserting(object sender, FormViewInsertEventArgs e)
        {
            TextBox txtCategoryName = fvaddcat.FindControl("txtCategoryName") as TextBox;
            if (txtCategoryName != null)
            {
                string categoryName = txtCategoryName.Text;
                SqlConnection sqlConn = new SqlConnection();
                sqlConn.ConnectionString = connectionString;
                String insertQuery = "insert into Category (Name) values(@Name)";
                SqlCommand sqlCommand = new SqlCommand(insertQuery, sqlConn);
                sqlCommand.Parameters.Add("@Name", SqlDbType.VarChar, 20).Value = categoryName;
                sqlConn.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConn.Close();
                sqlConn.Dispose();
                Response.Redirect("frmSalesList.aspx");
            }
            else
            {
                Label lblCategoryName = fvaddcat.FindControl("lblerror") as Label;
                lblCategoryName.Text = "Enter category name";
            }
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("frmSalesList.aspx");
        }
    }
}
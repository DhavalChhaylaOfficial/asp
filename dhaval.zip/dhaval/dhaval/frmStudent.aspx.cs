﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace dhaval
{
    public partial class frmStudent : System.Web.UI.Page
    {
        public SqlConnection sc = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CollegeDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        public SqlCommand cmd = new SqlCommand();
        public SqlDataReader sdr;

        protected void Page_Load(object sender, EventArgs e)
        {
            cmd.Connection = sc;
            cmd.CommandText = "StudentPro";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            if (!IsPostBack)
            {


                FillGrid();
                FillDropDown();
            }
        }
        private void FillDropDown()
        {
            try
            {

                sc.Open();
                cmd.Connection = sc;
                cmd.CommandText = "StudentPro";
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@op", 4);
                sdr = cmd.ExecuteReader();
                ddlid.Items.Clear();
                while (sdr.Read())
                {
                    ddlid.Items.Add(sdr[0].ToString());
                }
            }
            catch (Exception ex)
            {

                Response.Write(ex.Message);
            }
            finally
            {
                sc.Close();
                //FillGrid();
            }

        }

        private void FillGrid()
        {
            try
            {
                sc.Open();
                cmd.Connection = sc;
                cmd.CommandText = "StudentPro";
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@op", 5);
                sdr = cmd.ExecuteReader();
                gvstudent.DataSource = sdr;
                gvstudent.DataBind();

            }
            catch (Exception ex)
            {

                Response.Write(ex.Message);
            }
            finally
            {
                sc.Close();
                // FillDropDown();
            }
        }

        protected void btn_Insert_Click(object sender, EventArgs e)
        {
            try
            {
                sc.Open();
                cmd.Parameters.Clear();
                cmd.Connection = sc;
                cmd.CommandText = "StudentPro";
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", txt_id.Text);
                cmd.Parameters.AddWithValue("@name", txt_name.Text);
                cmd.Parameters.AddWithValue("@prog", txt_prog.Text);
                cmd.Parameters.AddWithValue("@sem", txt_sem.Text);
                cmd.Parameters.AddWithValue("@sub1", txt_sub1marks.Text);
                cmd.Parameters.AddWithValue("@sub2", txt_sub2marks.Text);
                cmd.Parameters.AddWithValue("@sub3", txt_sub3marks.Text);
                cmd.Parameters.AddWithValue("@op", 1);
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    Response.Write("Record Inserted");
                    txt_id.Text = "";
                    txt_name.Text = "";
                    txt_prog.Text = "";
                    txt_sem.Text = "";
                    txt_sub1marks.Text = "";
                    txt_sub2marks.Text = "";
                    txt_sub3marks.Text = "";
                }
                else
                {
                    Response.Write("Something Went Wrong");
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }
            finally
            {
                sc.Close();
                FillGrid();
                FillDropDown();
            }
        }

        protected void btn_Update_Click(object sender, EventArgs e)
        {
            try
            {
                sc.Open();
                cmd.Parameters.Clear();
                //cmd.Connection = sc;
                //cmd.CommandText = "StudentPro";
                //cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", ddlid.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@name", txt_name.Text);
                cmd.Parameters.AddWithValue("@prog", txt_prog.Text);
                cmd.Parameters.AddWithValue("@sem", txt_sem.Text);
                cmd.Parameters.AddWithValue("@sub1", txt_sub1marks.Text);
                cmd.Parameters.AddWithValue("@sub2", txt_sub2marks.Text);
                cmd.Parameters.AddWithValue("@sub3", txt_sub3marks.Text);
                cmd.Parameters.AddWithValue("@op", 2);
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    Response.Write("Record Updated");
                    txt_id.Text = "";
                    txt_name.Text = "";
                    txt_prog.Text = "";
                    txt_sem.Text = "";
                    txt_sub1marks.Text = "";
                    txt_sub2marks.Text = "";
                    txt_sub3marks.Text = "";
                }
                else
                {
                    Response.Write("Something Went Wrong");
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }
            finally
            {
                sc.Close();
                FillGrid();
                FillDropDown();
            }
        }

        protected void btn_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                sc.Open();
                cmd.Parameters.Clear();
                //cmd.Connection = sc;
                //cmd.CommandText = "StudentPro";
                //cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", ddlid.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@op", 3);
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    Response.Write("Record Deleted");
                    txt_id.Text = "";
                    txt_name.Text = "";
                    txt_prog.Text = "";
                    txt_sem.Text = "";
                    txt_sub1marks.Text = "";
                    txt_sub2marks.Text = "";
                    txt_sub3marks.Text = "";
                }
                else
                {
                    Response.Write("Something Went Wrong");
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.ToString());
            }
            finally
            {
                sc.Close();
                FillGrid();
                FillDropDown();
            }
        }

        protected void ddlid_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void gvstudent_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void gvstudent_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowIndex >= 0)
            {
                if (Convert.ToInt32(e.Row.Cells[4].Text) < 50)
                {
                    e.Row.Cells[4].ForeColor = System.Drawing.Color.Red;
                }

            }
        }
    }
}
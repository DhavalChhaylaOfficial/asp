﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace frmFileUpload
{
    public partial class frmFileUpload : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
           lblfuerror.Text = string.Empty;
            string fileName = fufile.FileName;
            string dt = DateTime.Now.ToString("ddmmyyhhmmss");
           string filepath = string.Empty;
            if(fufile.HasFile)
            {
                if (checkImageFile(fileName))
                {
                    filepath = "~/Image/" + dt + fileName;
                    imgUpload.ImageUrl= filepath;
                }
                else if(checkDocFile(fileName))
                {
                    filepath="~/word/" + dt + fileName;
                }
                else if(checkPdf(fileName))
                {
                    filepath="/pdf/" + dt + fileName;

                }
                else
                {
                    lblfuerror.Text = "invalid file selection";
                    lblfuerror.ForeColor = System.Drawing.Color.Red;
                }
                if(filepath!=string.Empty)
                {
                    fufile.SaveAs(MapPath(filepath));
                    lblfuerror.Text = "File uploaded successfully";
                    lblfuerror.ForeColor = System.Drawing.Color.Green;
                }
            }
            else
            {
                lblfuerror.Text = "Select a file!";
                lblfuerror.ForeColor = System.Drawing.Color.Red;
            }

        }
        private bool checkImageFile(string fileName)
        {
            string[] arr = new string[] { ".png", ".jpeg", ".jpg" };
            string ext = Path.GetExtension(fileName);
            return arr.Contains(ext);
        }
        private bool checkPdf(string fileName) {
            string[] arr = new string[] { ".pdf" };
            string ext = Path.GetExtension(fileName);
            return arr.Contains(ext);
        }
        private bool checkDocFile(string fileName)
        {
            string[] arr = new string[] { ".doc", ".docx" };
            string ext = Path.GetExtension(fileName);
                return arr.Contains(ext);
        }
        
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _26_09_23
{
    public partial class frmOrder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                for (int i = 1; i <= 31; i++)
                {
                    ddlDay.Items.Add(Convert.ToString(i));
                }

                for (int i = 1; i <= 12; i++)
                {
                    ddlMonth.Items.Add(Convert.ToString(i));
                }

                for (int i = 1995; i <= 2020; i++)
                {
                    ddlYear.Items.Add(Convert.ToString(i));
                }

            }
        }

        protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        { 
            bool err = false;
           
            lblErrMob.Text = string.Empty;
            lblErrPin.Text = string.Empty;



            if (txtFName.Text == string.Empty)
            {
                RegularExpressionValidator1.Text = "First Name Mustbe Char and maxlength is 5";
                err = true;
            }
            else
            {
                RegularExpressionValidator1.ErrorMessage = "*";
            }

            if (string.IsNullOrWhiteSpace(txtLname.Text))
            {
                RegularExpressionValidator2.Text = "Last Name is not in proper formate";
                err = true;
            }
            else
            {
                RegularExpressionValidator2.Text = "*";
            }

            if (string.IsNullOrWhiteSpace(txtMobile.Text))
            {
                lblErrMob.Text = "Mobile Number must be 10 Digits";
                err = true;
            }
            else
            {
                lblErrMob.Text = "*";
            }

            if (string.IsNullOrWhiteSpace(txtPin.Text))
            {
                lblErrPin.Text = "Pin Code must be 6 Digits";
                err = true;
            }
            else
            {
                lblErrPin.Text = "*";
            }

            if (string.IsNullOrWhiteSpace(txtCity.Text) )
            {
                RegularExpressionValidator3.Text = "City is not in proper formate";
                err = true;
            }
            else
            {
                RegularExpressionValidator3.Text = "*";
            }

           

            if (err == false)
            {
                string Fname = txtFName.Text;
                string Lname = txtLname.Text;
                string Email = txtEmail.Text;
                string Mobile = txtMobile.Text;
                string Address = txtAddress.Text;
                string City = txtCity.Text;
                string Pin = txtPin.Text;
                string State = txtState.Text;
                string Country = txtCountry.Text;
                string Gender = string.Empty;
                string Hobbies = string.Empty;
                string DOB = ddlDay.SelectedItem.Text + "/" + ddlMonth.SelectedItem.Text + "/" + ddlYear.SelectedItem.Text;
                string Qualification = "<br>Class X: " + " Board: " + txtXBoard.Text +
                    " Percentage: " + txtXPer.Text + " Year Of Passing: " + txtXYear.Text +
                    "<br>Class XII: " + " Board: " + txtXIIBoard.Text +
                    " Percentage: " + txtXIIPer.Text + " Year Of Passing: " + txtXIIYear.Text +
                    "<br>Gradution: " + " Board: " + txtGBoard.Text +
                    " Percentage: " + txtGPer.Text + " Year Of Passing: " + txtGYear.Text +
                    "<br>Masters: " + " Board: " + txtMBoard.Text +
                    " Percentage: " + txtMPer.Text + " Year Of Passing: " + txtMYear.Text;

                


                if (rbMale.Checked == true)
                {
                    Gender = rbMale.Text;
                }
                if (rbFemale.Checked == true)
                {
                    Gender = rbFemale.Text;
                }

                if (cbOther.Checked == true)
                {
                    Hobbies = txtOther.Text;
                }

                else
                {

                    foreach (ListItem lst in cblHobbies.Items)
                    {
                        if (lst.Selected == true)
                        {
                            Hobbies += lst.Text + ",";
                        }

                    }
                }
            

                lblResult.Text = "First Name: " + Fname + "<br>" +
                    "Last Name: " + Lname + "<br>" +
                    "Date Of Birth: " + DOB + "<br>" +
                    "Email: " + Email + "<br>" +
                    "Mobile No: " + Mobile + "<br>" +
                    "Gender: " + Gender + "<br>" +
                    "Address: " + Address + "<br>" +
                    "City: " + City + "<br>" +
                    "Pin Code: " + Pin + "<br>" +
                    "State: " + State + "<br>" +
                    "Country: " + Country + "<br>" +
                    "Qualification: " + Qualification + "<br>" +
                    "Hobbies: " + Hobbies + "<br>";
                
            }
            
        }

        protected void rbYes_CheckedChanged(object sender, EventArgs e)
        {
           

        }

        protected void rbNo_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtFName.Text = string.Empty;
            txtLname.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtMobile.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtCity.Text = string.Empty;
            txtPin.Text = string.Empty;
            txtState.Text = string.Empty;
            txtCountry.Text = string.Empty;
            txtXBoard.Text = string.Empty;
            txtXIIBoard.Text = string.Empty;
            txtMBoard.Text = string.Empty;
            txtGBoard.Text = string.Empty;
        }
    }
}
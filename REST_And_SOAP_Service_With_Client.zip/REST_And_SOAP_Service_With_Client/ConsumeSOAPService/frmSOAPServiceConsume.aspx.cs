﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;
using ConsumeSOAPService.SOAPServiceReference;

namespace ConsumeSOAPService
{
    public partial class frmSOAPServiceConsume : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnGetValue_Click(object sender, EventArgs e)
        {
            Service1Client client = new Service1Client();
            String value = client.GetData(Convert.ToInt32(txtValue.Text));
            lblGetValue.Text = value;
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            Service1Client client = new Service1Client();
            int no1 = Convert.ToInt32(txtNo1.Text);
            int no2 = Convert.ToInt32(txtNo2.Text);
            String add = client.AddNo(no1, no2);
            lblAdd.Text = add;

        }

        protected void btnOperation_Click(object sender, EventArgs e)
        {
            Service1Client client = new Service1Client();
            int no1 = Convert.ToInt32(txtNo1.Text);
            int no2 = Convert.ToInt32(txtNo2.Text);
            String opr = ddlOperation.SelectedValue;
            String ans = client.Operation(opr,no1, no2);
            lblOutput.Text = ans;
        }
    }
}
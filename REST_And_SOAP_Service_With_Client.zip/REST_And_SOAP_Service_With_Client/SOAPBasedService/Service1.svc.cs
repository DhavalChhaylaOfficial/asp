﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace SOAPBasedService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    // Debug -> Windows ->  Exception Settings -> Disable  "PInvokeStackImBalance"
    public class Service1 : IService1
    {
        public string GetData(int value)
        {
            return string.Format("You entered: {0} and square of = {1}", value,value*value);
        }
        public String AddNo(int no1,int no2) 
        {
            return string.Format("Addition of {0} + {1} = {2}", no1, no2, no1 + no2);
        }
        public String Operation(string opr,int no1,int no2)
        {
            switch(opr)
            {
                case "+":
                    return string.Format("Addition of {0} + {1} = {2}", no1, no2, no1 + no2);
                case "-":
                    return string.Format("Subtraction of {0} - {1} = {2}", no1, no2, no1 - no2);
                case "*":
                    return string.Format("Multiplication of {0} * {1} = {2}", no1, no2, no1 * no2);
                case "/":
                    if(no2 != 0)
                        return string.Format("Division of {0} / {1} = {2}", no1, no2, (float)no1 / no2);
                    else
                        return string.Format("Invalid number {0}",no2);
                default:
                    return "Invalid Option";
            }
        }
        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }
}

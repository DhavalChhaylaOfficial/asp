﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace ConsumeRestBasedXML
{
    public partial class frmRestClient : System.Web.UI.Page
    {
        private WebClient client; 
        protected void Page_Load(object sender, EventArgs e)
        {
            client  = new WebClient();
            client.DownloadStringCompleted += new DownloadStringCompletedEventHandler(
client_DownloadStringCompleted);
        }

        protected void btnOperation_Click(object sender, EventArgs e)
        {
            String no1 = txtNo1.Text;
            String no2 = txtNo2.Text;
            String opr = ddlOperation.SelectedValue;
            client.DownloadStringAsync
                (new Uri(
"http://localhost:50496/Service1.svc/" +
"operation/" + opr+"/"+no1+"/"+no2));
        }
        private void client_DownloadStringCompleted(object sender, 
            DownloadStringCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                XDocument xmlResponse = XDocument.Parse(e.Result);
                lblOutput.Text = xmlResponse.ToString();
            }
        }
        protected void btnGetValue_Click(object sender, EventArgs e)
        {

        }
    }
}
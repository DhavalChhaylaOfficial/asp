﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace RestBasedXML_Services
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : INumberOperation
    {
        public string GetData(String value)
        {
            return string.Format("You entered: {0}", value);
        }
        public String WelCome(String yourName)
        {
            return String.Format("Welcome {0} to REST Services", yourName);
        }
        public String Operation(String opr, String no1, String no2)
        {
            int n1 = Convert.ToInt32(no1);
            int n2 = Convert.ToInt32(no2);
            opr = opr.ToLower();
            switch(opr)
            {
                case "a":
                    return string.Format("{0} + {1} = {2}",n1,n2,n1+n2);
                case "s":
                    return string.Format("{0} - {1} = {2}", n1, n2, n1 - n2);
                case "m":
                    return string.Format("{0} * {1} = {2}", n1, n2, n1 * n2);
                case "d":
                    if (n2 != 0)
                        return string.Format("{0} / {1} = {2}", n1, n2, (float)n1 / n2) ;
                    else
                        return string.Format("Invalid no2");
                default:
                    return string.Format("Invalid Operation");

            }
        }
    }
}

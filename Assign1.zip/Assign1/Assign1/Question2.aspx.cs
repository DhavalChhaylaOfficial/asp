﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace Assign1
{
    public partial class Question2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            lblerror.Text = string.Empty;
            bool error = false;
            if (txtname.Text == string.Empty)
            {
                lblerror.Text = "Name is Required";
                error = true;
            }
            else
            {
                lblerror.Text = "*";
            }
            if (error == false)
            {
                string name = txtname.Text;
                lblmessage.Text = "Hello " + name + "..!!";
            }
        }
    }
}
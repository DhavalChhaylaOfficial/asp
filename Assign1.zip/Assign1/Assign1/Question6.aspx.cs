﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assign1
{
    public partial class Question6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void rdbLstImage_SelectedIndexChanged(object sender, EventArgs e)
        {
            int value = Convert.ToInt32(rdbLstImage.SelectedValue);
            switch (value)
            {
                case 1:
                    ImageSelectedImage.ImageUrl = "~/Images/blue_hills.jpeg";
                    break;
                case 2:
                    ImageSelectedImage.ImageUrl = "~/Images/sunset.jpeg";
                    break;
                case 3:
                    ImageSelectedImage.ImageUrl = "~/Images/water_lilies.jpeg";
                    break;
                case 4:
                    ImageSelectedImage.ImageUrl = "~/Images/winter.jpeg";
                    break;
            }
        }
    }
}
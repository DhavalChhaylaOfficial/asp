﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assign1
{
    public partial class Question4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            bool error = false;
            lblNoError.Text = string.Empty;
            if (txtno1.Text == string.Empty)
            {
                lblNoError.Text = "Number is required";
                error = true;
            }
            else
            {
                lblNoError.Text = "*";
            }
            if (error == false)
            {
                string selectedOperation = rbtnopertaion.SelectedValue;
                int number = Convert.ToInt32(txtno1.Text);

                switch (selectedOperation)
                {
                    case "square":
                        txtans.Text = (number * number).ToString();
                        break;
                    case "evenodd":
                        if (number % 2 == 0)
                        {
                            txtans.Text = "Even";
                        }
                        else
                        {
                            txtans.Text = "Odd";
                        }
                        break;
                    case "posneg":
                        if (number < 0)
                        {
                            txtans.Text = "Negative";
                        }
                        else
                        {
                            txtans.Text = "Positive";
                        }
                        break;
                    case "factorial":
                        int fac = 1;
                        for (int i = 2; i <= number; i++)
                        {
                            fac *= i;
                        }
                        txtans.Text = fac.ToString();
                        break;
                }
            }
        }
    }
}
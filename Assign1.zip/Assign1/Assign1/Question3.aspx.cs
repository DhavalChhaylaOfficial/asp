﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assign1
{
    public partial class Question3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            Calculate("+");
        }

        protected void btnsub_Click(object sender, EventArgs e)
        {
            Calculate("-");
        }

        protected void btnmult_Click(object sender, EventArgs e)
        {
            Calculate("*");
        }

        protected void btndiv_Click(object sender, EventArgs e)
        {
            Calculate("/");
        }
        private void Calculate(string operation)
        {
            bool error = false;
            lblNo1Error.Text = string.Empty;
            lblNo2Error.Text = string.Empty;
            if (txtno1.Text == string.Empty)
            {
                lblNo1Error.Text = "No1 is required";
                error = true;
            }
            else
            {
                lblNo1Error.Text = "*";
            }
            if (txtno2.Text == string.Empty)
            {
                lblNo2Error.Text = "No2 is required";
                error = true;
            }
            else
            {
                lblNo2Error.Text = "*";
            }
            if (error == false)
            {
                double num1 = Convert.ToDouble(txtno1.Text);
                double num2 = Convert.ToDouble(txtno2.Text);
                double ans = 0;
                switch (operation)
                {
                    case "+":
                        ans = num1 + num2;
                        break;
                    case "-":
                        ans = num1 - num2;
                        break;
                    case "*":
                        ans = num1 * num2;
                        break;
                    case "/":
                        if (num2 != 0)
                        {
                            ans = num1 / num2;
                        }
                        else
                        {
                            txtans.Text = "Cannot divide by zero!";
                            return;
                        }
                        break;
                }
                txtans.Text = ans.ToString();
            }
        }
    }
}

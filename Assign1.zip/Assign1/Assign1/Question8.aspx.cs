﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assign1
{
    public partial class Question8 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txtGreetingtext.ForeColor = System.Drawing.Color.Red;
        }
        protected void ddlChooseColor_SelectedIndexChanged(object sender, EventArgs e)
        {
            int value = Convert.ToInt32(ddlChooseColor.SelectedValue);
            switch (value)
            {
                case 1:
                    pnaoutput.CssClass = "bg-white";
                    break;
                case 2:
                    pnaoutput.CssClass = "bg-danger";
                    break;
                case 3:
                    pnaoutput.CssClass = "bg-warning";
                    break;
                case 4:
                    pnaoutput.CssClass = "bg-primary";
                    break;
                case 5:
                    pnaoutput.CssClass = "bg-success";
                    break;
                case 6:
                    pnaoutput.CssClass = "bg-danger-subtle";
                    break;
                case 7:
                    pnaoutput.CssClass = "bg-black";
                    break;
                case 8:
                    pnaoutput.CssClass = "bg-secondary";
                    break;
                case 9:
                    pnaoutput.CssClass = "bg-info";
                    break;
            }
        }
        protected void ddlfont_SelectedIndexChanged(object sender, EventArgs e)
        {
            int value = Convert.ToInt32(ddlfont.SelectedValue);
            switch (value)
            {
                case 1:
                    pnaoutput.Font.Name = "Times New Roman";
                    break;
                case 2:
                    pnaoutput.Font.Name = "Georgia";
                    break;
                case 3:
                    pnaoutput.Font.Name = "Baskerville Old Face";
                    break;
                case 4:
                    pnaoutput.Font.Name = "Arial Rounded MT Bold";
                    break;
                case 5:
                    pnaoutput.Font.Name = "Bahnschrift Light SemiCondensed";
                    break;
                case 6:
                    pnaoutput.Font.Name = "Californian FB";
                    break;
                case 7:
                    pnaoutput.Font.Name = "Book Antiqua";
                    break;
                case 8:
                    pnaoutput.Font.Name = "Castellar";
                    break;
                case 9:
                    pnaoutput.Font.Name = "Lucida Calligraphy";
                    break;
                case 10:
                    pnaoutput.Font.Name = "Sitka Small";
                    break;
                case 11:
                    pnaoutput.Font.Name = "Bell MT";
                    break;
                case 12:
                    pnaoutput.Font.Name = "Calibri";
                    break;
                case 13:
                    pnaoutput.Font.Name = "Felix Titling";
                    break;
                case 14:
                    pnaoutput.Font.Name = "Cascadia Code";
                    break;
                case 15:
                    pnaoutput.Font.Name = "Algerian";
                    break;
            }
        }
        protected void txtsize_TextChanged(object sender, EventArgs e)
        {
        }
        protected void rdbBorderstyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            int value = Convert.ToInt32(rdbBorderstyle.SelectedValue);
            switch (value)
            {
                case 1:
                    pnaoutput.BorderStyle = BorderStyle.None;
                    break;
                case 2:
                    pnaoutput.BorderStyle = BorderStyle.Double;
                    break;
                case 3:
                    pnaoutput.BorderStyle = BorderStyle.Solid;
                    break;
            }
        }
        protected void btnupdate_Click1(object sender, EventArgs e)
        {
            if (txtsize.Text == "8")
            {
                lblOutput.Font.Size = 8;
            }
            else if (txtsize.Text == "10")
            {
                lblOutput.Font.Size = 10;
            }
            else if (txtsize.Text == "10")
            {
                lblOutput.Font.Size = 10;
            }
            else if (txtsize.Text == "11")
            {
                lblOutput.Font.Size = 11;
            }
            else if (txtsize.Text == "12")
            {
                lblOutput.Font.Size = 12;
            }
            else if (txtsize.Text == "14")
            {
                lblOutput.Font.Size = 14;
            }
            else if (txtsize.Text == "16")
            {
                lblOutput.Font.Size = 16;
            }
            else if (txtsize.Text == "18")
            {
                lblOutput.Font.Size = 18;
            }
            else if (txtsize.Text == "20")
            {
                lblOutput.Font.Size = 20;
            }
            else if (txtsize.Text == "22")
            {
                lblOutput.Font.Size = 22;
            }
            else if (txtsize.Text == "24")
            {
                lblOutput.Font.Size = 24;
            }
            else if (txtsize.Text == "26")
            {
                lblOutput.Font.Size = 26;
            }
            else if (txtsize.Text == "28")
            {
                lblOutput.Font.Size = 28;
            }
            else if (txtsize.Text == "36")
            {
                lblOutput.Font.Size = 36;
            }
            else if (txtsize.Text == "48")
            {
                lblOutput.Font.Size = 48;
            }
            else if (txtsize.Text == "72")
            {
                lblOutput.Font.Size = 72;
            }
            else
            {
                lblerror.Text = "Invalid Value Choose According Font Size";
            }
            lblOutput.Text = txtGreetingtext.Text;
        }
        protected void chkpicture_CheckedChanged(object sender, EventArgs e)
        {
            if (chkpicture.Checked == true)
            {
                imgdefault.ImageUrl = "~/Images/blue_hills.jpeg";
            }
            else
            {
                imgdefault.ImageUrl = "";
            }
        }
    }
}
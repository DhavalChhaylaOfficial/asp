﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assign1
{
    public partial class Question5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            bool error = false;
            lblStringError.Text = string.Empty;
            if (txtstring.Text == string.Empty)
            {
                lblStringError.Text = "String is Required";
                error = true;
            }
            else
            {
                lblStringError.Text = "";
            }
            if (error == false)
            {

                string selectedOperation = rbtnopertaion.SelectedValue;
                string input = txtstring.Text.Trim();

                if (string.IsNullOrEmpty(input))
                {
                    lbloutput.Text = "Please enter a valid string.";
                    return;
                }

                string result = "";

                switch (selectedOperation)
                {
                    case "uppercase":
                        result = input.ToUpper();
                        break;
                    case "lowercase":
                        result = input.ToLower();
                        break;
                    case "right5":
                        if (input.Length >= 5)
                        {
                            result = input.Substring(input.Length - 5);
                        }
                        else
                        {
                            result = input;
                        }
                        break;
                    case "left5":
                        if (input.Length >= 5)
                        {
                            result = input.Substring(0, 5);
                        }
                        else
                        {
                            result = input;
                        }
                        break;
                }

                txtoutput.Text = result;
            }
        }
    }
}
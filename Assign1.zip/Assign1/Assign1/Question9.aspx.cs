﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assign1
{
    public partial class Question9 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCalculate_Click(object sender, EventArgs e)
        {
            
            int rollNo = Convert.ToInt32(txtRollNo.Text);
            string name = txtName.Text;
            int sub1 = Convert.ToInt32(txtSub1.Text);
            int sub2 = Convert.ToInt32(txtSub2.Text);
            int sub3 = Convert.ToInt32(txtSub3.Text);
            int sub4 = Convert.ToInt32(txtSub4.Text);
            int sub5 = Convert.ToInt32(txtSub5.Text);
            if ((sub1 >= 1 && sub1 <= 100) && (sub2 >= 1 && sub2 <= 100) && (sub3 >= 1 && sub3 <= 100) && (sub4 >= 1 && sub4 <= 100) && (sub5 >= 1 && sub5 <= 100))
            {
                double total = sub1 + sub2 + sub3 + sub4 + sub5;
                txtTotal.Text = total.ToString();

                double percentage = (total / 500) * 100;
                txtPercentage.Text = percentage.ToString("F2");

                if (percentage > 90)
                {
                    txtGrade.Text = "A+";
                }
                else if (percentage >= 80)
                {
                    txtGrade.Text = "A";
                }
                else if (percentage >= 70)
                {
                    txtGrade.Text = "B+";
                }
                else if (percentage >= 60)
                {
                    txtGrade.Text = "B";
                }
                else if (percentage >= 50)
                {
                    txtGrade.Text = "C+";
                }
                else if (percentage >= 40)
                {
                    txtGrade.Text = "C";
                }
                else
                {
                    txtGrade.Text = "F";
                }
            }
            else
            {
                lblValidationMessage1.Text = "Subject marks should between 1 to 100 only..!!";
            }
                
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtRollNo.Text = "";
            txtName.Text = "";
            txtSub1.Text = "";
            txtSub2.Text = "";
            txtSub3.Text = "";
            txtSub4.Text = "";
            txtSub5.Text = "";
            txtTotal.Text = "";
            txtGrade.Text = "";
            txtPercentage.Text = "";
        }
    }
}
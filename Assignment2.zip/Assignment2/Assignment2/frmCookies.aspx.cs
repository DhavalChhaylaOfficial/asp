﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment2
{
    public partial class frmCookies : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.Header.Title += DateTime.Now.ToString("dd-MM-yyyy"); Style mystyle = new Style();
            mystyle.BackColor = System.Drawing.Color.Green;
            Page.Header.StyleSheet.CreateStyleRule(mystyle, null, "#first");
        }
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            String userValue = null; String userName = txtName.Text; userValue = txtValue.Text;
            HttpCookie userInfo = new HttpCookie("userInfo"); userInfo["userName"] = txtName.Text; userInfo["userValue"] = txtValue.Text; userInfo.Expires.Add(new TimeSpan(0, 1, 0)); Response.Cookies.Add(userInfo);
            if (!string.IsNullOrEmpty(userValue.Trim()))
            {
                if ((ddlValue.Items.FindByText(userValue) == null))
                {
                    ddlValue.Items.Add(new ListItem(userValue, userValue)); ddlValue.SelectedIndex = ddlValue.SelectedIndex + 1;
                }
            }
            if (Response.Cookies != null)
            {
                lblOutputViewCookie.Text = txtName.Text + " has been write successfully";
                lblOutputViewCookie.CssClass = "text-warning"; txtName.Text = string.Empty; txtValue.Text = string.Empty;
            }
            else
            {
                lblOutputViewCookie.Text = "Cookies Required"; lblOutputViewCookie.Text = "text-danger";
            }
        }
        protected void btnView_Click(object sender, EventArgs e)
        {
            string User_name = string.Empty;
            string User_value = string.Empty;
            HttpCookie reqCookies = Request.Cookies["UserInfo"]; if (reqCookies != null)
            {
                User_name = reqCookies["userName"].ToString(); User_value = reqCookies["userValue"].ToString(); if (ddlValue.Text == User_value)
                {
                    lblOutputViewCookie.Text = "UserName : " + User_name + "UserValue: " + ddlValue.Text;
                }
            }
        }
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            lblOutputViewCookie.Text = ddlValue.SelectedItem.Value + " IsDeleted!";
            lblOutputViewCookie.CssClass = "text-danger"; ddlValue.Items.RemoveAt(ddlValue.SelectedIndex); HttpCookie userInfo = new HttpCookie("userInfo");
            if (Request.Cookies["userInfo"].Value == ddlValue.SelectedItem.Value)
            {
                Response.Cookies["userInfo"].Expires = DateTime.Now.AddDays(-1);
            }

        }

    }
}